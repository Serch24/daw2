CREATE USER sergio@localhost IDENTIFIED by '1234';

use examen2eva;


GRANT SELECT on brawl usuarios, registro_vacuna,censo,vacuna to sergio@localhost;

